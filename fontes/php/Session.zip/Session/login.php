<html>
	<head>
	<title></title>
	</head>
	<body>
		<form action="validaLogin.php" method="post" id="form" name="form">
			<label for="login">Login: <input type="text" name="login" id="login" /></label>
			<label for="senha">Senha: <input type="password" name="senha" id="senha" /></label>
			<button type="submit">LOGIN</button>
		</form>
	
	</body>
</html>