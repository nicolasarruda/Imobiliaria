<?php
include('login_paginas.php');

$id = session_id();

    echo "<h1>Seja bem-vindo, ".$_SESSION["user"]."</h1>";
	
	echo "A id é: ".$id;
	
	echo '<form action="sair.php" method="post" id="form" name="form">
			<button type="submit">SAIR</button>
		</form>';

?>
<a href="pagina2.php">página2</a>