<?php
include('login_paginas.php');
?>

<html>
<head>

</head>

<body>

	<p>estou na página 2</p>

<a href="home.php">pagina 1</a>

</body>

</html>