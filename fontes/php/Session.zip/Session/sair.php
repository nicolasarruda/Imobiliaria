<?php
//INICIO A SESSÃO
session_start();

session_destroy();
 
//if (session_destroy()) {
//    echo "Sessão destruída";
//}
//else {
//    echo "Não foi possível destruir a sessão";
//}
header("Location: login.php");
?>