<?php
if (isset($_POST['nome'])) {
   $nome=$_POST['nome'];
} else {
   $nome="";
}

if (isset($_POST['cidade'])) {
   $cidade=$_POST['cidade'];
} else {
   $cidade="";
}

if (isset($_POST['sexo'])) {
   $sexo=$_POST['sexo'];
} else {
   $sexo="";
}

if (isset($_POST['tablet'])) {
   $tablet=$_POST['tablet'];
} else {
   $tablet="";
}
?>
<HTML>
   <HEAD>
      <TITLE>Exemplo de Formulario - leitura dos dados</TITLE>
   </HEAD>
   <BODY>
      <CENTER>
         <P><U>DADOS PESSOAIS</U></P>
         <P>NOME: <?php echo $nome; ?></P>
         <P>CIDADE: <?php echo $cidade; ?></P>
         <P>SEXO: <?php echo $sexo; ?></P>
         <P>POSSUI TABLET ?: <?php echo $tablet; ?></P>
      </CENTER>
   </BODY>
</HTML>